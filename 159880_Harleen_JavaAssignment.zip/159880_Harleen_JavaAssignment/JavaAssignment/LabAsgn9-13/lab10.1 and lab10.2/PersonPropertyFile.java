package com.cg.project.inputoutput;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Enumeration;
import java.util.Properties;

public class PersonPropertyFile {
	public static void main(String[] args) throws FileNotFoundException, IOException {
		Properties property=new Properties();
		property.setProperty("Name", "Gajendra");
		property.setProperty("Pas", "ASDFGG");
		property.store(new FileOutputStream(new File(".//resources//PersonProps.properties")),"This is Comments");
		
		property.load(new FileInputStream(new File(".//resources//PersonProps.properties")));
		 Enumeration<?> e =property.propertyNames();
		while(e.hasMoreElements()){
			String key=(String)e.nextElement();
			String value=property.getProperty(key);
			System.out.println(key+","+value);
		}
	}

}
