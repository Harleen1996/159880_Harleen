package com.cg.project.inputoutput;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class NumberFile {
	public static void main(String[] args) throws FileNotFoundException {
		File file=new File("D:\\Users\\ADM-IG-HWDLAB1D\\Desktop\\textfile3.txt");
		Scanner scanner=new Scanner(new FileInputStream(file));
		String s[]=scanner.nextLine().split(",");
		for(int i=0;i<s.length;i++){
			if(Integer.parseInt(s[i])%2==0)
				System.out.println(s[i]);
		}
	}

}
