package com.cg.project.inputoutput;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
public class ReadingWritingContent {
	public static void readingContent() throws IOException{
		BufferedReader bf=new BufferedReader(new FileReader(new File("D:\\Users\\ADM-IG-HWDLAB1D\\Desktop\\textfile1.txt")));
		String string=bf.readLine();
		File toWrite=new File("D:\\Users\\ADM-IG-HWDLAB1D\\Desktop\\textfile3.txt");
		if(!toWrite.exists())
			toWrite.createNewFile();
		BufferedWriter br=new BufferedWriter(new FileWriter(toWrite));
		String out="";
		for(int i=string.length()-1;i>=0;i--)
			out+=string.charAt(i);
		br.write(out);
		br.flush();
	}
}
