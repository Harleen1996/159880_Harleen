/*package com.cg.lab2;

import java.util.Scanner;

public class MainClassForGenderInputRestriction {

	public static void main(String[] args) {
		PersonalDetailsWithGenderInputRestriction personalDetails=new PersonalDetailsWithGenderInputRestriction();
		Scanner s=new Scanner(System.in);
		personalDetails.setFirstName(s.nextLine());
		personalDetails.setLastName(s.nextLine());
		personalDetails.
		personalDetails.setAge(s.nextInt());
		personalDetails.setWeight(s.nextFloat());
		personalDetails.setMobileNo(s.nextLong());
		personalDetails.printDetails();

	}

}
*/